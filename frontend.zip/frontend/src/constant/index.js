export const SET_WEB3 = 'SET_WEB3';
export const WALLET_CONNECT = 'WALLET_CONNECT';
export const TOKEN_LIST = 'TOKEN_LIST';
export const ALLOWED_PAIRS = 'ALLOWED_PAIRS';
export const IS_ELIGIBLE = 'IS_ELIGIBLE';