export async function useAllCommonPairs() {

    return "yes";
}